
export default {
  id: state => state.user.id 
}
