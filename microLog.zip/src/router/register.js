
export default {

  path: '/register',
  component: () => import('@/page/user/loginAndRegister.vue')

}
