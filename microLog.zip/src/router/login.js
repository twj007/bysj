
export default {
	path: '/login',
	component: () => import('@/page/user/loginAndRegister.vue')
}
