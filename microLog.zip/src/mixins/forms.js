export const loginForm = {
    username: '',
    password: '',
    remember: false
};

export const registerForm = {
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
};
