module.exports = {
  node: {
    nodeURL: 'localhost',
    port: 3000
  },
  vue: {
    vueURL: 'localhost',
    port: 8080
  },
  java: {
    javaURL: 'localhost',
    port: 8081
  },
  accessKey: '2018bysjtwj1415!'
}
//aes密钥 必须为16个字节
